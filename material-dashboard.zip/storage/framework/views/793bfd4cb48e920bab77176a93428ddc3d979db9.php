<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Solicitudes</h4>
            <p class="card-category"> Listado de las solicitudes Aceptadas</p>

          </div>
          <div class="card-body">
               
                <a href="solicitudes/create" class="btn btn-primary">Nueva Solicitud</a>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>
                    ID
                  </th>
                  <th>
                    Name
                  </th>
                  <th>
                    Country
                  </th>
                  <th>
                    City
                  </th>
                  <th>
                    Salary
                  </th>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td>
                      <?php echo e($solicitud->detalle); ?> 
                    </td>
                    <td>
                      <?php echo e($solicitud->reemplazo); ?>

                    </td>
                    <td>
                      <?php echo e($solicitud->fecha_desde); ?>

                    </td>
                    <td>
                      <?php echo e($solicitud->fecha_hasta); ?>

                    </td>
                    <td class="text-primary">
                      <?php echo e($solicitud->estado); ?>

                    </td>
                  </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
  
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Solicitud', 'titlePage' => __('Solicitudes')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/pages/solicitud.blade.php ENDPATH**/ ?>