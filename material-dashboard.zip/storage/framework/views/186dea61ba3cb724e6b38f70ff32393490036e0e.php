

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
           <div class="card-header card-header-primary">
            <h4 class="card-title ">Roles</h4>
            <p class="card-category"> Listado de los Roles </p>
            </div>
                  <div class="container">

                            <div class="panel-body">
                            <p><strong>Nombre</strong>     <?php echo e($role->name); ?></p>
                            <p><strong>Slug</strong>       <?php echo e($role->slug); ?></p>
                            <p><strong>Descripción</strong>  <?php echo e($role->description); ?></p>
                            </div>
                    </div



          </div>
          </div>
          </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Roles', 'titlePage' => __('Roles')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/roles/show.blade.php ENDPATH**/ ?>