<?php echo Form::open(['method' => 'DELETE', 'route' => ['solicitud.destroy',$solicitud->id]]); ?>


  <input type="submit" value="Eliminar" class="btn btn-danger">

<?php echo Form::close(); ?>

<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/pages/delete.blade.php ENDPATH**/ ?>