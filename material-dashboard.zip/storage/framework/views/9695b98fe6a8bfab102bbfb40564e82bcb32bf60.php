
<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">


            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Crear Perfil')); ?></h4>
                <p class="card-category"><?php echo e(__('Informacion del Usuario')); ?></p>
              </div>
               <?php if(session('info')): ?>
              <div class="container">

                       <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('info')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>

              </div>
            <?php endif; ?>
    				<div class="card-body ">
              <?php echo Form::open(['route' => 'user.store']); ?>


                          <?php echo $__env->make('users.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <?php echo Form::close(); ?>

    				</div>

            </div>

        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Usuarios', 'titlePage' => __('Usuario')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/users/create.blade.php ENDPATH**/ ?>