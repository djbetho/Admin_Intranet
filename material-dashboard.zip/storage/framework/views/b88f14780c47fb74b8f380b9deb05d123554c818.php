

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
           
<?php echo e($solicitud); ?>


	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitud.destroy')): ?>
	include('pages.delete')
	<?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Solicitud', 'titlePage' => __('Solicitudes')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/pages/show.blade.php ENDPATH**/ ?>