<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Editar Perfil')); ?></h4>
                <p class="card-category"><?php echo e(__('Informacion del Usuario')); ?></p>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nombre')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('name')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Apellido')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('apellido') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" name="apellido" id="input-name" type="text" placeholder="<?php echo e(__('apellido')); ?>" value="<?php echo e(old('apellido', auth()->user()->apellido)); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('apellido')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('apellido')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Rut')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('rut') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('rut') ? ' is-invalid' : ''); ?>" name="rut" id="input-name" type="text" placeholder="<?php echo e(__('rut')); ?>" value="<?php echo e(old('rut', auth()->user()->rut)); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('rut')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('rut')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Direccion')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('direccion') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" id="input-name" type="text" placeholder="<?php echo e(__('direccion')); ?>" value="<?php echo e(old('direccion', auth()->user()->direccion)); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('direccion')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('direccion')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Telefono')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('telefono') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" name="telefono" id="input-name" type="text" placeholder="<?php echo e(__('telefono')); ?>" value="<?php echo e(old('telefono', auth()->user()->telefono)); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('telefono')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('telefono')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email', auth()->user()->email)); ?>" required />
                      <?php if($errors->has('email')): ?>
                        <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('profile.password')); ?>" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Cambiar la contraseña')); ?></h4>
                <p class="card-category"><?php echo e(__('Contraseña')); ?></p>
              </div>
              <div class="card-body ">
                <?php if(session('status_password')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">cerrar</i>
                        </button>
                        <span><?php echo e(session('status_password')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Contraseña actual')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('old_password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" input type="password" name="old_password" id="input-current-password" placeholder="<?php echo e(__('Contraseña actual')); ?>" value="" required />
                      <?php if($errors->has('old_password')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('old_password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password"><?php echo e(__('Nueva contraseña')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="input-password" type="password" placeholder="<?php echo e(__('Nueva contraseña')); ?>" value="" required />
                      <?php if($errors->has('password')): ?>
                        <span id="password-error" class="error text-danger" for="input-password"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Confirme nueva contraseña')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="<?php echo e(__('Confirme nueva contraseña')); ?>" value="" required />
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Cambiar contraseña')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Perfil', 'titlePage' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/profile/edit.blade.php ENDPATH**/ ?>