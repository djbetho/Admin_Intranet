

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Solicitudes</h4>
            <p class="card-category"> Listado de las solicitudes Aceptadas</p>

          </div>
          <div class="card-body">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitud.create')): ?>
                <a href="solicitud/create" class="btn btn-primary">Nueva Solicitud</a>
              <?php endif; ?>
              <?php echo e(Form::open(['route' => 'solicitud.index', 'method' => 'GET', 'class' => 'form-inline pull-right'])); ?>

              <div class="input-group no-border">
                  <div class="form-group">
                      <?php echo e(Form::text('detalle', null, ['class' => 'form-control', 'placeholder' => 'Buscar'])); ?>

                  </div>
              </div>
              <div class="form-group">
                  <button type="submit" class="btn btn-default">
                      <span class="glyphicon glyphicon-search">Buscar</span>
                  </button>
              </div>
           <?php echo e(Form::close()); ?>

          </div>

           <?php if(session('info')): ?>
              <div class="container">

                       <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('info')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>

              </div>
            <?php endif; ?>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>
                    Solicitud
                  </th>
                  <th>
                    Reemplazo
                  </th>
                  <th>
                    Fecha Inicio
                  </th>
                  <th>
                   Fecha Hasta
                  </th>
                  <th>
                   Cantidad
                  </th>
                  <th>
                    Estado
                  </th>
                  <th colspan="3">
                    Accion
                  </th>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $solicitud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitudes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td>
                      <?php echo e($solicitudes->detalle); ?>

                    </td>
                    <td>
                      <?php echo e($solicitudes->reemplazo); ?>

                    </td>
                    <td>
                      <?php echo e($solicitudes->fecha_desde); ?>

                    </td>
                    <td>
                      <?php echo e($solicitudes->fecha_hasta); ?>

                    </td>
                    <td>
                      <?php echo e($solicitudes->cantidad_dias); ?>

                    </td>
                    <td class="text-primary" width="10px">
                      <?php switch($solicitudes->estado):
                            case (0): ?>
                                Pendiente
                                <?php break; ?>

                            <?php case (1): ?>
                                 Aceptado
                                 <?php break; ?>
                            <?php case (2): ?>
                                 Rechazado
                                 <?php break; ?>

                            <?php default: ?>
                                Nulo
                        <?php endswitch; ?>
                    </td>
                    <td  width="5px">
                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitud.show')): ?> <a href="solicitud/<?php echo e($solicitudes->id); ?>" class="btn btn-sm btn-default" >Ver</a><?php endif; ?>
                    </td>
                    <td width="5px">
                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitud.edit')): ?><a href="solicitud/<?php echo e($solicitudes->id); ?>/edit" class="btn btn-sm btn-default">editar</a><?php endif; ?>
                    </td >
                    <td width="5px">
                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitud.destroy')): ?>



                            <?php echo Form::open(['route' => ['solicitud.destroy', $solicitudes->id],
                                    'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger">
                                            Eliminar
                                        </button>
                                    <?php echo Form::close(); ?>



                       <?php endif; ?>
                    </td>


                  </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
                <?php echo e($solicitud->links()); ?>

            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Solicitud', 'titlePage' => __('Solicitudes')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/pages/index.blade.php ENDPATH**/ ?>