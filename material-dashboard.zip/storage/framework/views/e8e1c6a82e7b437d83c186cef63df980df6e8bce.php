

<?php echo Form::open(['route' => [$solicitud->url(),$solicitud->id],'method' => $solicitud ->method(),'class'=>'form']); ?>



 <div class="card-body">
	<div class="form-group">
		<?php echo Form::label('title', 'Rut'); ?>

		<?php echo Form::text('rut',   auth()->user()->rut  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Detalle de la solicitud', []); ?>

		<?php echo Form::text('detalle', $solicitud ->detalle, ['class'=> 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Reemplazo'); ?>

		<?php echo Form::text('reemplazo', $solicitud ->reemplazo , ['class'=> 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::checkbox('cantidad_fech', 'value'); ?>

		<?php echo Form::label('title', 'Mas de un dia '); ?>


	</div>
	<div class="form-group">

    <input name= "fecha_desde" id="fecha_desde" placeholder="Fecha desde..." type="text" class="form-control datetimepicker" value=<?php echo e($solicitud ->fecha_desde); ?>>
  </div>

  <div class="form-group">

      <input name= "fecha_hasta" id="fecha_hasta" placeholder="Fecha hasta..." type="text" class="form-control datetimepicker" value=<?php echo e($solicitud ->fecha_hasta); ?> >
  </div>

  <?php echo e($nombre_semestre_actual); ?>


  </div>

<button type="submit"  class="btn btn-primary">Guardar</button>


<?php echo Form::close(); ?>

<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/pages/form.blade.php ENDPATH**/ ?>