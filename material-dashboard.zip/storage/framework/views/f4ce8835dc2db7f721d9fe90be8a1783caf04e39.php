<div class="sidebar" data-color="azure" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
      <?php echo e(__('Intranet')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('home')): ?>

      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
     <?php endif; ?>

     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitud.index')): ?>
      <li class="nav-item<?php echo e($activePage == 'Solicitud' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('solicitud.index')); ?>">
          <i class="material-icons">content_paste</i>
            <p><?php echo e(__('Solicitudes')); ?></p>
        </a>
      </li>
     <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('licencia.index')): ?>
      <li class="nav-item<?php echo e($activePage == 'licencias' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('licencia.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Licencias Medicas')); ?></p>
        </a>
      </li>
     <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asistencia.index')): ?>
      <li class="nav-item<?php echo e($activePage == 'Asistencia' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('asistencia.index')); ?>">
          <i class="material-icons">bubble_chart</i>
          <p><?php echo e(__('Asistencia')); ?></p>
        </a>
      </li>
      <?php endif; ?>

      <li class="nav-item ">
        <a class="nav-link collapsed" data-toggle="collapse" href="#pagesExamples" aria-expanded="false">
          <i class="material-icons">image</i>
          <p> Reportes
            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="pagesExamples" style="">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'Permisos' ? ' active' : ''); ?>">
              <a class="nav-link" href="#">
                <span class="sidebar-mini"> P </span>
                <span class="sidebar-normal"> Permisos </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'Asistencias' ? ' active' : ''); ?>">
              <a class="nav-link" href="#">
                <span class="sidebar-mini"> A </span>
                <span class="sidebar-normal"> Asistencias </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'Licencias' ? ' active' : ''); ?>">
              <a class="nav-link" href="#">
                <span class="sidebar-mini"> L </span>
                <span class="sidebar-normal"> Licencias </span>
              </a>
            </li>

          </ul>
        </div>
      </li>
      <li class="nav-item ">
        <a class="nav-link collapsed" data-toggle="collapse" href="#pagesAdmin" aria-expanded="false">
          <i class="material-icons">image</i>
          <p> Administracion
            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="pagesAdmin" style="">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.index')): ?>
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'Usuarios' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> P </span>
                <span class="sidebar-normal"> Usuarios </span>
              </a>
            </li>
              <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index')): ?>
            <li class="nav-item<?php echo e($activePage == 'Roles' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                <span class="sidebar-mini"> A </span>
                <span class="sidebar-normal"> Roles </span>
              </a>
            </li>


            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permision.index')): ?>
            <li class="nav-item<?php echo e($activePage == 'Permisos' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('permision.index')); ?>">
                <span class="sidebar-mini"> L </span>
                <span class="sidebar-normal"> Permisos </span>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('semestre.index')): ?>
            <li class="nav-item<?php echo e($activePage == 'Semestres' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('semestre.index')); ?>">
                <span class="sidebar-mini"> S </span>
                <span class="sidebar-normal"> Semestres </span>
              </a>
            </li>
            <?php endif; ?>

          </ul>
        </div>
      </li>




  </div>
</div>
<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>