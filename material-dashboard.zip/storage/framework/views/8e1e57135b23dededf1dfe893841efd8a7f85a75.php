

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Permisos</h4>
            <p class="card-category"> Listado de los Permisos </p>

          </div>
          <div class="card-body">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permision.create')): ?>
                   <a href="<?php echo e(route('permision.create')); ?>"
                   class="btn btn-sm btn-primary pull-right">
                       Crear
                   </a>
                   <?php endif; ?>
          </div>

              <div class="container">
                <?php if(session('info')): ?>
                   <div class="container">

                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                             <strong><?php echo e(session('info')); ?></strong>
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                             </button>
                           </div>

                   </div>
                 <?php endif; ?>
              </div>

          <div class="card-body">
            <div class="table-responsive">
                  <table class="table">
                <thead>
                      <tr>
                          <th width="10px">ID</th>
                          <th>Nombre</th>
                            <th>URL Amigable</th>
                              <th>Descripcion</th>
                          <th colspan="3">&nbsp;</th>
                      </tr>
                  </thead>
                  <tbody>
                           <?php $__currentLoopData = $Permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td><?php echo e($permiso->id); ?></td>
                               <td><?php echo e($permiso->name); ?></td>
                               <td><?php echo e($permiso->slug); ?></td>
                               <td><?php echo e($permiso->description); ?></td>
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permision.show')): ?>
                               <td width="10px">
                                   <a href="<?php echo e(route('permision.show', $permiso->id)); ?>"
                                   class="btn btn-sm btn-default">
                                       ver
                                   </a>
                               </td>
                               <?php endif; ?>
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permision.edit')): ?>
                               <td width="10px">
                                   <a href="<?php echo e(route('permision.edit', $permiso->id)); ?>"
                                   class="btn btn-sm btn-default">
                                       editar
                                   </a>
                               </td>
                               <?php endif; ?>
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permision.destroy')): ?>
                               <td width="10px">
                                   <?php echo Form::open(['route' => ['permision.destroy', $permiso->id],
                                   'method' => 'DELETE']); ?>

                                       <button class="btn btn-sm btn-danger">
                                           Eliminar
                                       </button>
                                   <?php echo Form::close(); ?>

                               </td>
                               <?php endif; ?>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                   </table>
                   <?php echo e($Permission->render()); ?>



            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Permisos', 'titlePage' => __('Roles')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/permission/index.blade.php ENDPATH**/ ?>