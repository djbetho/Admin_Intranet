
<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
						<div class="card">
							<div class="card-header card-header-primary">
									<h4 class="card-title ">Editar  Permiso</h4>
									<p class="card-category"> Editar Permiso</p>

								</div>
								<div class="panel-body">
										 <div class="card-body">
	 						     <?php echo Form::model($Permission, ['route' => ['permision.update', $Permission->id],'method' => 'PUT']); ?>


	 						         <?php echo $__env->make('permission.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	 						     <?php echo Form::close(); ?>

								 </div>
	 						 </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Permisos', 'titlePage' => __('Roles')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/permission/edit.blade.php ENDPATH**/ ?>