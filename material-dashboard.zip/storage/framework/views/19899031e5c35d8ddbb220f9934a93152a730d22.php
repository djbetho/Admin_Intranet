<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Solicitud de permiso</title>
</head>
<body>

    <p>Hola! Se ha solicitado una nueva solicitud de permiso</p>
    <p>Estos son los datos de la solicitud </p>
    <li>rut: <?php echo e($RecordSolicitud->rut); ?></li>
    <li>Detalle: <?php echo e($RecordSolicitud->detalle); ?></li>
    <li>Reemplazo: <?php echo e($RecordSolicitud->reemplazo); ?></li>
    <li>Fecha hasta: <?php echo e($RecordSolicitud->fecha_desde); ?></li>
    <li>Fecha desde: <?php echo e($RecordSolicitud->fecha_hasta); ?></li>
</body>
</html>
<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/mail/send.blade.php ENDPATH**/ ?>