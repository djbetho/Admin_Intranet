

<?php echo Form::open(['route' => [$user->url(),$user->id],'method' => $user->method(),'class'=>'form']); ?>



 <div class="card-body">
	<div class="form-group">
		<?php echo Form::label('title', 'Rut'); ?>

		<?php echo Form::text('rut',   $user->rut  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Nombre'); ?>

		<?php echo Form::text('name',   $user->name  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Apellido'); ?>

		<?php echo Form::text('apellido',   $user->apellido  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Direccion'); ?>

		<?php echo Form::text('direccion',   $user->direccion  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Telefono'); ?>

		<?php echo Form::text('telefono',   $user->telefono  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Email'); ?>

		<?php echo Form::text('email',   $user->email  , ['class' => 'form-control']); ?>

	</div>

  <h3>Lista de roles</h3>
 <div class="form-group">
 	<ul class="list-unstyled">
 		<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 	    <li>
 	        <label>
 	        <?php echo e(Form::checkbox('roles[]', $role->id, null,old('roles'))); ?>

 	        <?php echo e($role->name); ?>

 	        <em>(<?php echo e($role->description); ?>)</em>
 	        </label>
 	    </li>
 	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
 </div>
 <div class="form-group">
 	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

 </div>

<?php echo Form::close(); ?>

<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/users/form.blade.php ENDPATH**/ ?>