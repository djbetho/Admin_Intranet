<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
      <thead>
        <tr>
          <td>Rut</td>
          <td>Nombre</td>
          <td>Correo</td>

          <td>Direccion</td>
          <td>telefono</td>
        </tr>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($user->rut); ?></td>
              <td><?php echo e($user->name); ?> <?php echo e($user->apellido); ?></td>
              <td><?php echo e($user->email); ?></td>
             
              <td><?php echo e($user->direccion); ?></td>
              <td><?php echo e($user->telefono); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </thead>
    </table>
  </body>
</html>
<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/pdf/user.blade.php ENDPATH**/ ?>