
<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
						<div class="card">
							<div class="card-header card-header-primary">
									<h4 class="card-title ">Editar  semestre</h4>
									<p class="card-category"> Editar semestre</p>

								</div>
								<div class="panel-body">
										 <div class="card-body">
	 						     <?php echo Form::model($semestre, ['route' => ['semestre.update', $semestre->id],'method' => 'PUT']); ?>


	 						         <?php echo $__env->make('semestres.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	 						     <?php echo Form::close(); ?>

								 </div>
	 						 </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Semestres', 'titlePage' => __('Roles')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/semestres/edit.blade.php ENDPATH**/ ?>