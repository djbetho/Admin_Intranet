

<?php echo Form::open(['route' => [$role->url(),$role->id],'method' => $role ->method(),'class'=>'form']); ?>



 <div class="card-body">
	<div class="form-group">
		<?php echo Form::label('title', 'Nombre'); ?>

		<?php echo Form::text('name',   $role->name  , ['class' => 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'URL Amigable', []); ?>

		<?php echo Form::text('slug',  $role->slug, ['class'=> 'form-control']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('title', 'Descripcion'); ?>

		<?php echo Form::text('description',  $role->description , ['class'=> 'form-control']); ?>

	</div>
	<div class="form-group">
    <hr>
    <h3>Permiso especial</h3>
    <div class="form-group">
     	<label><?php echo e(Form::radio('special', 'all-access')); ?> Acceso total</label>
     	<label><?php echo e(Form::radio('special', 'no-access')); ?> Ningún acceso</label>
    </div>
    <hr>
    <h3>Lista de permisos</h3>
    <div class="form-group">
    	<ul class="list-unstyled">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <label>
            <?php echo e(Form::checkbox('permissions[]', $permission->id, null)); ?>

            <?php echo e($permission->name); ?>

            <em>(<?php echo e($permission->description); ?>)</em>
            </label>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <div class="form-group">
    	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    </div>
	</div>




<?php echo Form::close(); ?>

<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/roles/form.blade.php ENDPATH**/ ?>