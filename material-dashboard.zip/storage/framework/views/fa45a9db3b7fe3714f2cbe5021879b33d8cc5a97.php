<div class="form-group">
	<?php echo e(Form::label('name', 'Nombre del Semestre')); ?>

	<?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>
<div class="form-group">
			<label class="label-control">Fecha inicio</label>
			<input name= "fecha_ini" type="text" class="form-control datetimepicker" value=<?php echo e($semestre ->fecha_ini); ?>/>
</div>
<div class="form-group">
				<label class="label-control">Fecha Termino</label>
				<input name= "fecha_term" type="text" class="form-control datetimepicker" value=<?php echo e($semestre ->fecha_term); ?>/>
</div>
<div class="form-group">
	<?php echo e(Form::label('name', 'Cantidad goce de remuneraciones')); ?>

	<?php echo e(Form::number('cantidad', null, ['class' => 'form-control', 'id' => 'cantidad'])); ?>

</div>

<div class="form-group">
	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>
<?php /**PATH /home/vagrant/code/material-dashboard/resources/views/semestres/partials/form.blade.php ENDPATH**/ ?>