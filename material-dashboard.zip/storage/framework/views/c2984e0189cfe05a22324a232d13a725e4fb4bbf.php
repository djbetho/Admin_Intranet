<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">Usuarios</h4>
              <p class="card-category"> Aqui puedes Administrar todos los usuarios</p>
            </div>
            <div class="card-body">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?>

                <a href="<?php echo e(route('user.pdf')); ?>" class="btn btn-sm btn-primary">  Exportar datos a <span class="material-icons"> picture_as_pdf</span></a>
                <a href=" " class="btn btn-sm btn-primary">  Importar datos  <span class="material-icons"> publish</span></a>

              <div class="row">
                <div class="col-12 text-right">
                  <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-primary">Agregar nuevo Usuario</a>
                </div>
              </div>
                <?php endif; ?>
                          <?php echo e(Form::open(['route' => 'user.index', 'method' => 'GET', 'class' => 'form-inline pull-right'])); ?>

                          <div class="input-group no-border">
                              <div class="form-group">
                                  <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Buscar'])); ?>

                              </div>
                          </div>
                          <div class="form-group">
                              <button type="submit" class="btn btn-default">
                                  <span class="glyphicon glyphicon-search">Buscar</span>
                              </button>
                          </div>
                       <?php echo e(Form::close()); ?>

              <div class="table-responsive">
                <table class="table">
                  <thead class=" text-primary">
                    <tr><th>
                        Rut
                    </th>
                    <th>
                      Nombre
                    </th>
                    <th>
                      Email
                    </th>
                    <th>
                      Direccion
                    </th>
                    <th>
                      Telefono
                    </th>



                    <th class="text-right">
                      Actions
                    </th>
                  </tr></thead>
                  <tbody>
                     <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                              <td>
                             <?php echo e($user->rut); ?>

                              </td>

                              <td width="25px">
                               <?php echo e($user->name); ?>

                              </td>
                              <td width="10px">
                               <?php echo e($user->email); ?>

                              </td>
                               <td>
                               <?php echo e($user->direccion); ?>

                              </td>

                              <td width="5px">
                               <?php echo e($user->telefono); ?>

                              </td>


                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.edit')): ?>
                              <td class="td-actions text-right">
                                    <a rel="tooltip" class="btn btn-success btn-link" href="user/<?php echo e($user->id); ?>/edit" data-original-title="" title="">
                              <i class="material-icons">edit</i>
                              <?php endif; ?>
                              <div class="ripple-container"></div>
                              </a>
                                </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                </table>
                  <?php echo $users->render(); ?>

              </div>
            </div>
          </div>

      </div>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Usuarios', 'titlePage' => __('Usuarios')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/material-dashboard/resources/views/users/index.blade.php ENDPATH**/ ?>