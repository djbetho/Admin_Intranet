<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
       
    </nav>
  <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>,   <i class="material-icons"></i> 
        <a href="https://www.60seg.cl" target="_blank">Desarrollado con Laravel</a> 
        </div>
  </div>
</footer>